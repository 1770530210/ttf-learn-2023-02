Wiki

-   TrueType
    [http://en.wikipedia.org/wiki/TrueType](http://en.wikipedia.org/wiki/TrueType)
-   OpenType
    [http://en.wikipedia.org/wiki/OpenType](http://en.wikipedia.org/wiki/OpenType)

Microsoft Typography
[http://www.microsoft.com/typography/default.mspx](http://www.microsoft.com/typography/default.mspx)

-   Font specifications
    [http://www.microsoft.com/typography/SpecificationsOverview.mspx](http://www.microsoft.com/typography/SpecificationsOverview.mspx),
    including OpenType and TrueType.
-   Font Tools
    [http://www.microsoft.com/typography/tools/tools.aspx](http://www.microsoft.com/typography/tools/tools.aspx)

Apple

-   TrueType reference manual
    [http://developer.apple.com/fonts/TTRefMan](http://developer.apple.com/fonts/TTRefMan)

Adobe

-   OpenType
    [http://www.adobe.com/type/opentype/](http://www.adobe.com/type/opentype/)
