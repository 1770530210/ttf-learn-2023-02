/**
 * This package contain, the font display tool SFView to display the GSUB sub-tables and
 * there interdependencies. This is an experimental package. Please treat this code as an
 * alpha code.
 *  
 * @author Cibu Johny
 */
package com.google.typography.font.sfntly.sample.sfview;